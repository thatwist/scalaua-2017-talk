# scalaua-2017-talk
Resources and materials for a talk given at scalaua 2017 conference
